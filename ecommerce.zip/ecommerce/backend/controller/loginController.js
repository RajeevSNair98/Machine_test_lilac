
const userCollection = require('../models/userModel')


exports.loginController = async(req,res)=>{
    const {email,password} = req.body
    try {
        const user = await userCollection.findOne({email})
        if(!user){
            return res.json({message:"invalid user"})
        }
        if(user){
            if(user.password == password){
                return res.json({success:true,message:"Loggedin successfully"})
            }else{
                return res.json({message:"Wrong password"})
            }
        }
    } catch (error) {
        console.log(error);
    }
}


exports.registerController = async(req,res)=>{
    try {
        const {name,email,password} = req.body
        switch(true){
            case !name:
                return res.json({success:false,message:'Name is required'})
            case !email:
                return res.json({message:'Email is required'})    
            case !password:
                 return res.json({message:'Password is required'})                          
            }

            const user = await new userCollection({name:name,email:email,password:password}).save()
            res.status(200).json({
                success:true,
                message:"user created successfully",
                user
            })

    } catch (error) {
        console.log(error);
        res.status(500).send({
            success:false,
            message:'error in creating user'
        })
    }
}


