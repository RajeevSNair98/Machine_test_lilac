import './App.css';
import Login from './components/Login/Login';
import Register from './components/Login/Register';
import MainPage from './components/MainPage/MainPage';
import {BrowserRouter,Routes,Route} from 'react-router-dom'

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
            <Route path='/' element={<MainPage/>} />
            <Route path='/login' element={<Login/>} />
            <Route path='/register' element={<Register/>} />
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
