 import React from 'react'
 import Carousel from 'nuka-carousel'
 import './Carousel.css'
 import { Box } from '@mui/material'
 import ecom1 from '../assets/ecom1.png'
 import ecom2 from '../assets/ecom2.png'
 import ecom3 from '../assets/ecom3.png'

 const Carousels = () => {

     const slides = [
         "https://img.freepik.com/free-psd/special-sales-banner-template_23-2148975924.jpg",
         "https://img.freepik.com/free-psd/sales-horizontal-banner-template_23-2148912910.jpg",
         "https://img.freepik.com/free-psd/horizontal-banner-template-big-sale-with-woman-shopping-bags_23-2148786755.jpg"
     ]

     const params = {
         wrapAround: true, 
         animation:'zone',
         slidesToShow:2,
         adaptiveHeight:true,
         defaultControlsConfig:{
             containerClassName:' containerClassName',
             nextButtonClassName:'nextButtonClassName',
             prevButtonClassName:'prevButtonClassName'
         }
     }

   return (
    //   <Box sx={{marginTop:'70px',width:'1650px'}}>
    //       <Carousel {...params}>
    //           {
    //               slides.map((slide)=>(
    //                   <img src={slide} key={slide}/>
    //               ))
    //          }
    //       </Carousel>
    //   </Box>
     <Box sx={{marginTop:'70px',width:'1250px'}}>
         <Carousel {...params} style={{width:'1700px',height:'400px'}}>
             <img src={ecom1} alt="" />
           <img src={ecom2} alt="" />
           <img src={ecom3} alt="" />
       </Carousel>
   </Box>
   )
 }

 export default Carousels

