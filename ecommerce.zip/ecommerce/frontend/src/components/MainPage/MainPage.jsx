import React from 'react'
import Header from '../Header/Header';
import MainHeader from '../Header/MainHeader';
import Carousels from '../Carousel/Carousel';
import BestDeals from '../BestDeals/BestDeals';
import Footer from '../Footer/Footer';
import ProductList from '../ProductList/ProductList';


const MainPage = () => {
  return (
    <div>
     <Header/>
    <MainHeader/>
    <Carousels/>
    <BestDeals/>
    <ProductList/>
    <Footer/>
    </div>
  )
}

export default MainPage