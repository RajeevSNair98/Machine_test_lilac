import React from 'react'
import './BestDeals.css'

const BestDeals = () => {
  return (
    <div>
        <section className='home-wrapper-2 py-5'>
            <div className="container-xxl">
                <div className="row">
                    <div className="col-12">
                        <div className="categories d-flex justify-content-between align-items-center">
                            <div className="d-flex gap-30 align-items-center">
                                <img className='best-img' src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fpisces.bbystatic.com%2Fimage2%2FBestBuy_US%2Fimages%2Fproducts%2F6070%2F6070001_rd.jpg&f=1&nofb=1&ipt=5734f304c44b530fc00217e679e851042a417ee32b897fc20ec1a181856b93b8&ipo=images" alt="" />
                                <div style={{marginBottom:'60px', marginLeft:'20px'}}>
                                    <p style={{padding:'0',margin:'0'}}>Fitness And</p>
                                    <p>Activity Tracker</p>
                                    <h6 style={{color:'blue'}}>$ 3.33</h6>
                                </div>
                            </div>

                            <div className=" d-flex gap-30 align-items-center">
                                <img className='best-img' src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fpisces.bbystatic.com%2Fimage2%2FBestBuy_US%2Fimages%2Fproducts%2F6070%2F6070001_rd.jpg&f=1&nofb=1&ipt=5734f304c44b530fc00217e679e851042a417ee32b897fc20ec1a181856b93b8&ipo=images" alt="" />
                                <div style={{marginBottom:'60px', marginLeft:'20px'}}>
                                    <p style={{padding:'0',margin:'0'}}>Fitness And</p>
                                    <p>Activity Tracker</p>
                                    <h6 style={{color:'blue'}}>$ 3.33</h6>
                                </div>
                            </div>

                            <div className="d-flex gap-30 align-items-center">
                                <img className='best-img' src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fpisces.bbystatic.com%2Fimage2%2FBestBuy_US%2Fimages%2Fproducts%2F6070%2F6070001_rd.jpg&f=1&nofb=1&ipt=5734f304c44b530fc00217e679e851042a417ee32b897fc20ec1a181856b93b8&ipo=images" alt="" />
                                <div style={{marginBottom:'60px', marginLeft:'20px'}}>
                                    <p style={{padding:'0',margin:'0'}}>Fitness And</p>
                                    <p>Activity Tracker</p>
                                    <h6 style={{color:'blue'}}>$ 3.33</h6>
                                </div>
                            </div>

                            <div className="d-flex gap-30 align-items-center">
                                <img className='best-img' src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fpisces.bbystatic.com%2Fimage2%2FBestBuy_US%2Fimages%2Fproducts%2F6070%2F6070001_rd.jpg&f=1&nofb=1&ipt=5734f304c44b530fc00217e679e851042a417ee32b897fc20ec1a181856b93b8&ipo=images" alt="" />
                                <div style={{marginBottom:'60px', marginLeft:'20px'}}>
                                    <p style={{padding:'0',margin:'0'}}>Fitness And</p>
                                    <p>Activity Tracker</p>
                                    <h6 style={{color:'blue'}}>$ 3.33</h6>
                                </div>
                            </div>

                            <div className="d-flex gap-30 align-items-center">
                                <img className='best-img' src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fpisces.bbystatic.com%2Fimage2%2FBestBuy_US%2Fimages%2Fproducts%2F6070%2F6070001_rd.jpg&f=1&nofb=1&ipt=5734f304c44b530fc00217e679e851042a417ee32b897fc20ec1a181856b93b8&ipo=images" alt="" />
                                <div style={{marginBottom:'60px', marginLeft:'20px'}}>
                                    <p style={{padding:'0',margin:'0'}}>Fitness And</p>
                                    <p>Activity Tracker</p>
                                    <h6 style={{color:'blue'}}>$ 3.33</h6>
                                </div>
                            </div>

                            <div className="d-flex gap-30 align-items-center">
                                <img className='best-img' src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fpisces.bbystatic.com%2Fimage2%2FBestBuy_US%2Fimages%2Fproducts%2F6070%2F6070001_rd.jpg&f=1&nofb=1&ipt=5734f304c44b530fc00217e679e851042a417ee32b897fc20ec1a181856b93b8&ipo=images" alt="" />
                                <div style={{marginBottom:'60px', marginLeft:'20px'}}>
                                    <p style={{padding:'0',margin:'0'}}>Fitness And</p>
                                    <p>Activity Tracker</p>
                                    <h6 style={{color:'blue'}}>$ 3.33</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
  )
}

export default BestDeals