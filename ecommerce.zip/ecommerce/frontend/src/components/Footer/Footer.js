import React from 'react'
import './Footer.css'
import DomainIcon from "@mui/icons-material/Domain";
import {BsLinkedin,BsGithub,BsYoutube,BsInstagram} from 'react-icons/bs'


const Footer = () => {
  return (
    <div>
        <footer className='py-5 my-3 '>
            <div className="container-xxl bg-primary">
                <div className="row align-items-center">
                    <div className="col-6">
                        <div className="footer-top-data d-flex gap-30 align-items-center">
                            <DomainIcon style={{fontSize:'100px'}}/>
                            <h4 className='fw-bold text-white' style={{marginLeft:'40px'}}>Sign up for Newsletter</h4>
                        </div>
                        <p className='text-white' style={{marginLeft:'140px',marginBottom:'60px'}}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    </div>
                    <div className="col-6">
                        <div className="input-group">
                            <input type="text"
                            className='form-control py-1 p-3'
                            placeholder='Enter your Email here...' 
                            />
                     <span className='input-group-text '>
                            Subscribe
                            </span>
                        </div>
    
                    </div>
                </div>
            </div>
        </footer>

        <footer className='py-3'>
            <div className="container-xxl">
                <div className="row">
                    <div className="col-3 ">
                        <div className='d-flex mx-3 my-1 '>
                        <DomainIcon/>
                        <h4 className='text-dark mb-4 fw-bold mx-3'>LoremIpsum</h4>
                        </div>
                       <div>
                            <address className='fs-6 text-secondary'>Hno: 122 neae asd asds,
                                sonopar,haryana <br />
                                pinc :121212
                            </address>
                            <div className="social_icons d-flex align-items-center gap-30">
                               <BsLinkedin className='fs-1 text-secondary'/>
                               <BsInstagram className='fs-1 mx-5 text-secondary'/>
                               <BsGithub className='fs-1 mx-1 text-secondary'/>
                               <BsYoutube className='fs-1 mx-5 text-secondary'/>
                            </div>
                       </div>
                    </div>
                    <div className="col-2">
                    <h5 className='text-dark mb-2 fw-bold'>QUICK LINKS</h5>
                    <div className='footer-links d-flex flex-column'>
                        <a href="" className=' text-decoration-none pt-2 text-secondary'>Products</a>
                        <a href="" className=' text-decoration-none pt-2 text-secondary'>Classifieds</a>
                        <a href="" className=' text-decoration-none pt-2 text-secondary'>Contact Us</a>
                        <a href="" className=' text-decoration-none pt-2 text-secondary'>Login</a>
                        <a href="" className=' text-decoration-none pt-2 text-secondary'>Sign Up</a>
                    </div>
                    </div>
                    <div className="col-2">
                    <h5 className='text-dark mb-2 fw-bold'>CUSTOMER AREA</h5>
                    <div className='footer-links d-flex flex-column'>
                        <a href="" className=' text-decoration-none pt-2 text-secondary'>My account</a>
                        <a href="" className=' text-decoration-none pt-2 text-secondary'>Orders</a>
                        <a href="" className=' text-decoration-none pt-2 text-secondary'>Tracking List</a>
                        <a href="" className=' text-decoration-none pt-2 text-secondary'>Terms</a>
                        <a href="" className=' text-decoration-none pt-2 text-secondary'>Privacy Policy</a>
                        <a href="" className=' text-decoration-none pt-2 text-secondary'>Return Policy</a>
                        <a href="" className=' text-decoration-none pt-2 text-secondary'>My Cart</a>
                    </div>
                    </div>
                    <div className="col-2">
                    <h5 className='text-dark mb-2 fw-bold'>VENDOR AREA</h5>
                    <div className='footer-links d-flex flex-column'>
                    <a href="" className='text-secondary text-decoration-none pt-2'>Partner with us</a>
                        <a href="" className='text-secondary text-decoration-none pt-2'>Training</a>
                        <a href="" className='text-secondary text-decoration-none pt-2'>Procedures</a>
                        <a href="" className='text-secondary text-decoration-none pt-2'>Terms</a>
                        <a href="" className='text-secondary text-decoration-none pt-2'>Privacy Policy</a>
                    </div>
                    </div>
                    <div className="col-3">
                    <h5 className='text-dark mb-4 fw-bold'>CONTACT</h5>
                    <div className='footer-links d-flex flex-column'>
                       <p className='text-secondary'>Lorem ipsum dolor,Lorem ipsum dolor,Lorem ipsum dolor,</p>
                    
                    <div className='d-flex'>
                        <div>
                        <p className='fs-6'>Have any questions</p>
                        <a href="" className='text-decoration-none'>+123 456 789</a>
                        </div>
                        <button style={{width:'100px',backgroundColor:'white'}} className='mx-4 m-1 p-2'>Chat</button>
                    </div>

                    </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
  )
}

export default Footer