import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import PhoneIcon from '@mui/icons-material/Phone';
import MailIcon from '@mui/icons-material/Mail';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import { MenuItem,InputLabel,Select,FormControl } from '@mui/material';



const styles = {
    flexBox: {
      display: 'flex',
      alignItems: 'center',
    },
    separator: {
      margin: '0 10px',
    },
  };

function Header() {
 
      

  return (
    <AppBar position="static">
    <Container maxWidth="xl">
      <Toolbar disableGutters>
        <Box sx={styles.flexBox} marginLeft={5}>
          <PhoneIcon />
          <Box marginLeft={2}>
            <Typography>+221 33 66 22</Typography>
          </Box>
        </Box>

        <Box sx={styles.flexBox} marginLeft={5}>
          <MailIcon />
          <Box marginLeft={2}>
            <Typography>support@elextra.io</Typography>
          </Box>
        </Box>

        <Box sx={styles.flexBox} marginLeft={'auto'} marginRight={5}>
          <LocationOnIcon />
          <Box marginLeft={2}>
            <Typography>Location</Typography>
          </Box>
        </Box>

        <Typography sx={styles.separator}>|</Typography>

        <FormControl sx={{ width: '150px', marginBottom: '7px' }}>
          <InputLabel sx={{ color: 'white' }}>$ Dollar (US)</InputLabel>
          <Select variant="standard" disableUnderline label="Age" color="white">
            <MenuItem value={10}>Ten</MenuItem>
            <MenuItem value={20}>Twenty</MenuItem>
            <MenuItem value={30}>Thirty</MenuItem>
          </Select>
        </FormControl>

        <FormControl sx={{ width: '70px', marginBottom: '7px', marginRight: '35px' }}>
          <InputLabel sx={{ color: 'white' }}>EN</InputLabel>
          <Select variant="standard" disableUnderline label="Age">
            <MenuItem value={10}>Ten</MenuItem>
            <MenuItem value={20}>Twenty</MenuItem>
            <MenuItem value={30}>Thirty</MenuItem>
          </Select>
        </FormControl>
      </Toolbar>
    </Container>
  </AppBar>
  );
}
export default Header;