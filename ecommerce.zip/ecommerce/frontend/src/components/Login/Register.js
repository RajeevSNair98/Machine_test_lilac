import React from "react"
import './Login.css'
import axios from "axios"
import { useState } from 'react'
import {toast} from 'react-hot-toast'
import {Link, useNavigate} from 'react-router-dom'


export default function Register() {

  const [name,setName] = useState('')
  const [email,setEmail] = useState('')
  const [password,setPassword] = useState('')

  const navigate = useNavigate()

  const handleSubmit = async(e)=>{
    e.preventDefault()
    try {
        const res = await axios.post('http://localhost:4000/api/v1/register',
        {name,email,password})
         if(res.data.success){
             alert(res.data.message)
             navigate('/')
         }else{
             alert(res.data.message)
         }
    } catch (error) {
        console.log(error);
        toast.error("Something went wrong")
    }
}

    

  return (
    <div className="Auth-form-container">
      <form className="Auth-form" onSubmit={handleSubmit}>
        <div className="Auth-form-content">
          <h3 className="Auth-form-title">Sign In</h3>
          <div className="form-group mt-3">
            <label>Name</label>
            <input
              type="text"
              className="form-control mt-1"
              placeholder="Enter email"
              value={name} onChange={(e)=>setName(e.target.value)}
            />
          </div>
          <div className="form-group mt-3">
            <label>Email</label>
            <input
              type="email"
              className="form-control mt-1"
              placeholder="Enter password"
              value={email} onChange={(e)=>setEmail(e.target.value)}
            />
          </div>
          <div className="form-group mt-3">
            <label>Password</label>
            <input
              type="password"
              className="form-control mt-1"
              placeholder="Enter password"
              value={password} onChange={(e)=>setPassword(e.target.value)}
            />
          </div>
          <div className="d-grid gap-2 mt-3">
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
            <button type="submit" className="btn btn-secondary">
            <Link to={'/'} className="text-white text-decoration-none" >Back to home page</Link>
            </button>
          </div>
        </div>
      </form>
    </div>
  )
}